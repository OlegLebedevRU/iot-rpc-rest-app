# src/common/captcha.py
"""
Валидация Яндекс Smart Captcha на бэкенде

Пример использования:
    from captcha import validate_captcha
    
    # В endpoint'е логина:
    token = request.headers.get('Smart-Captcha-Token')
    if not await validate_captcha(token, request.client.host):
        raise HTTPException(status_code=400, detail="Captcha validation failed")
"""

import os
import httpx
from typing import Optional

# Серверный ключ (начинается с ysc2_)
# Получить можно в https://smartcaptcha.yandex.ru/
# Добавьте ваш ключ в переменную окружения SMART_CAPTCHA_SERVER_KEY
SMART_CAPTCHA_SERVER_KEY = os.getenv(
    "SMART_CAPTCHA_SERVER_KEY", 
    ""  # ВАЖНО: Добавьте ваш серверный ключ здесь или в переменную окружения
)

# URL для валидации токена
VALIDATE_URL = "https://smartcaptcha.yandex.net/validate"


async def validate_captcha(token: Optional[str], client_ip: str) -> bool:
    """
    Валидирует токен капчи от Яндекса.
    
    Args:
        token: Токен, полученный от фронтенда
        client_ip: IP адрес пользователя
    
    Returns:
        True если капча пройдена успешно
    """
    if not token:
        return False
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                VALIDATE_URL,
                data={
                    "secret": SMART_CAPTCHA_SERVER_KEY,
                    "token": token,
                    "ip": client_ip,
                },
                timeout=10.0,
            )
            
            if response.status_code == 200:
                result = response.json()
                #response.json() => {"status": "ok"} или {"status": "failed", "code": ...}
                return result.get("status") == "ok"
            else:
                return False
        except Exception:
            # При ошибке лучше пропустить (fail open) или заблокировать (fail closed)
            # Для продакшена рекомендуется fail closed
            return False


def validate_captcha_sync(token: Optional[str], client_ip: str) -> bool:
    """
    Синхронная версия валидации капчи.
    """
    if not token:
        return False
    
    try:
        response = httpx.post(
            VALIDATE_URL,
            data={
                "secret": SMART_CAPTCHA_SERVER_KEY,
                "token": token,
                "ip": client_ip,
            },
            timeout=10.0,
        )
        
        if response.status_code == 200:
            result = response.json()
            return result.get("status") == "ok"
        return False
    except Exception:
        return False
